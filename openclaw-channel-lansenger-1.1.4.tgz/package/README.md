# OpenClaw Lansenger Channel Plugin

## 项目简介

OpenClaw Lansenger Channel Plugin 是 OpenClaw 平台的蓝信渠道插件，用于实现 OpenClaw 与蓝信消息平台的集成。该插件支持：

- 接收蓝信消息并转发到 OpenClaw
- 发送消息从 OpenClaw 到蓝信

## 功能特性

### 连接方式
- WebSocket 长连接
- 支持蓝信开放平台 API

## 安装与配置

### 安装插件

```bash
openclaw plugins install @lansenger/openclaw-lansenger
```

安装成功后会显示：`Installed plugin: openclaw-lansenger`

### 初始化配置

```bash
openclaw channels add --channel Lansenger --token "{AppID}:{App Secret}:{Api Gateway URL}"
```

其中：
- `{AppID}`：蓝信应用的 App ID
- `{App Secret}`：蓝信应用的 App Secret
- `{Api Gateway URL}`：蓝信开放平台 API 网关地址


## 蓝信应用配置

1. **创建应用**：在蓝信PC客户端(version>=9.5.50)-个人机器人-创建机器人
2. **获取凭据**：从创建结果页面，获取 App ID 和 App Secret/API Gateway URL并配置到openclaw

## 使用指南

### 基本使用

1. **发送文本消息**：直接在聊天中输入消息，机器人会自动处理
2. **使用 Markdown**：直接使用 Markdown 语法，插件会自动处理


### 消息格式

#### Markdown 格式

蓝信支持 Markdown 格式。

#### 卡片消息

支持 linkCard、appCard 等卡片消息格式，可根据需要使用不同的卡片类型。

## 常见问题


### 消息类型支持
- 部分消息类型可能需要蓝信应用具备相应权限
- 大文件可能会受到蓝信平台的大小限制

### 错误处理
- 查看 OpenClaw 日志了解详细错误信息
- 检查蓝信应用配置是否正确
- 确保网络连接正常
